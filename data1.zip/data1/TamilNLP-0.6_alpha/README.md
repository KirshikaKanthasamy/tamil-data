இந்த தளத்தில் தமிழில் இயல்மொழி பகுப்பாய்வுக்கான நிரல்கள், கருவிகள் மற்றும் படைப்புகள் பதிவிறக்கம் செய்யலாம்:
#### [விக்கிப்பீடியா தமிழ் உரைத்தொகுப்பு (text corpus)](https://github.com/AshokR/TamilNLP/wiki/Wikipedia-Text-Corpus)
#### [TXM உரைத்தொகுப்பு பகுப்பாய்வு செய்யும் கருவி](https://github.com/AshokR/TamilNLP/wiki/TXM-Corpus-Analysis-Tool)
#### [தமிழ் சொல்வகை குறியிடும் கருவி (POS tagger)](https://github.com/AshokR/TamilNLP/wiki/POS-Tagger)
#### [தமிழ் உரை சுருக்கம் செய்யும் நிரல்](https://github.com/AshokR/TamilNLP/wiki/Text-Summary-Extractor)
#### [தமிழ் வாக்கிய பிரிப்பான்](https://github.com/AshokR/TamilNLP/wiki/Tamil-Sentence-Splitter)
#### [அடிக்கடி பயன்படுத்தும் வார்த்தைகள் (Stopwords)](https://github.com/AshokR/TamilNLP/wiki/Stopwords)
---
Copyright © 2016 இரா. அசோகன்
Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at http://www.apache.org/licenses/LICENSE-2.0

The above copyright notice and this permission notice shall be included in all copies or substantial portions of the Software.

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
